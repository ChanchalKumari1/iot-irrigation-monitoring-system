ESP32 Soil Moisture MQTT Project

Pins Used:
- Soil Moisture Sensor -> GPIO 34

Features:
- Sends moisture data every 30 seconds
- Publishes moisture status (DRY/WET)
- Controls pump via MQTT topic (irrigation/pump)

Replace WiFi credentials before uploading.
