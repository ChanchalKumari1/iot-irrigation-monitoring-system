#include <WiFi.h>
#include <PubSubClient.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

#define SOIL_SENSOR_PIN 34

int moistureValue = 0;
unsigned long lastMsg = 0;

void setup_wifi() {
  delay(10);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

void reconnect() {
  while (!client.connected()) {
    if (client.connect("ESP32Client")) {
      // connected
    } else {
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsg > 30000) {
    lastMsg = now;

    moistureValue = analogRead(SOIL_SENSOR_PIN);

    String statusMsg;
    if (moistureValue < 2000) {
      statusMsg = "DRY";
      client.publish("irrigation/pump", "ON");
    } else {
      statusMsg = "WET";
      client.publish("irrigation/pump", "OFF");
    }

    client.publish("irrigation/moisture", String(moistureValue).c_str());
    client.publish("irrigation/status", statusMsg.c_str());
  }
}
